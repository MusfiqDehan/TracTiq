import { execSync } from "node:child_process";
import path from "node:path";
import { expect, test } from "@playwright/test";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8003";

async function resetSeedState() {
  try {
    const res = await fetch(`${API_URL}/api/test/reset`, { method: "POST" });
    if (res.ok) return;
  } catch {
    // fallback to CLI reset when APP_ENV != test
  }
  const repoRoot = path.resolve(__dirname, "../..");
  execSync("uv run seed-db --reset", {
    cwd: path.join(repoRoot, "backend"),
    stdio: "inherit",
  });
}

test.describe("Level 10 Meeting Two-Browser Real-Time Sync", () => {
  test("fails when Observer context attempts facilitator-only section advance", async ({
    browser,
  }) => {
    await resetSeedState();

    const facilitatorCtx = await browser.newContext({
      viewport: { width: 1280, height: 720 },
      recordVideo: {
        dir: path.resolve(__dirname, "../test-results/videos/facilitator"),
        size: { width: 1280, height: 720 },
      },
    });
    const observerCtx = await browser.newContext({
      viewport: { width: 1280, height: 720 },
      recordVideo: {
        dir: path.resolve(__dirname, "../test-results/videos/observer"),
        size: { width: 1280, height: 720 },
      },
    });

    const facilitatorPage = await facilitatorCtx.newPage();
    const observerPage = await observerCtx.newPage();

    await facilitatorPage.goto("/teams/team_lead/meeting?as=u2");
    await observerPage.goto("/teams/team_lead/meeting?as=u5");

    // 1. Facilitator starts Level 10 Meeting
    const startBtn = facilitatorPage.getByTestId("start-meeting-btn");
    await expect(startBtn).toBeVisible();
    await startBtn.click();

    // Both browsers enter Scorecard and display server-owned timer
    await expect(facilitatorPage.getByTestId("meeting-timer")).toBeVisible();
    await expect(observerPage.getByTestId("meeting-timer")).toBeVisible();
    await expect(observerPage.getByTestId("scorecard-section")).toBeVisible();

    // 2. Facilitator flags off-track Scorecard cell (m1, 2026-10-26) as Issue
    await facilitatorPage.getByTestId("make-issue-m1-2026-10-26").click();
    await expect(
      facilitatorPage.getByText("Issue created from Scorecard")
    ).toBeVisible({ timeout: 5000 });

    // 3. Facilitator advances section from Scorecard -> IDS
    await facilitatorPage.getByTestId("advance-section-btn").click();

    // Observer browser follows transition to IDS in real time without reload
    await expect(observerPage.getByTestId("issues-section")).toBeVisible({
      timeout: 5000,
    });
    await expect(
      observerPage.getByText("New deals closed – 2026-10-26")
    ).toBeVisible({ timeout: 5000 });

    // 4. Intentional failure sample:
    // Asserting that an Observer (u5 - Ellis Evans) has facilitator-only
    // Advance Section controls fails because RBAC enforces read-only mode
    // across UI (omitted controls), API (403), and DB trigger layers.
    await expect(
      observerPage.getByTestId("advance-section-btn")
    ).toBeVisible({ timeout: 2000 });
  });
});
